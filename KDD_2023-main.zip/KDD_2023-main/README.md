# KDD_2023
Sistemas de recomendación Amazon TASK1
